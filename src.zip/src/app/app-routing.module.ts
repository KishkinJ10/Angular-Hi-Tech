import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { AddExistingCustomerComponent } from './pages/application/add-existing-customer/add-existing-customer.component';
import { AddNewCustomerComponent } from './pages/application/add-new-customer/add-new-customer.component';
import { CreateApplicationComponent } from './pages/application/create-application/create-application.component';
import { MyApplicationComponent } from './pages/application/my-application/my-application.component';
import { SearchApplicationComponent } from './pages/application/search-application/search-application.component';
import { CreateBankComponent } from './pages/bank/create-bank/create-bank.component';
import { PatchUpdateBankComponent } from './pages/bank/patch-update-bank/patch-update-bank.component';
import { UpdateBankComponent } from './pages/bank/update-bank/update-bank.component';
import { HomeComponent } from './pages/base/home/home.component';
import { CalculatorComponent } from './pages/calculator/calculator.component';
import { CreateEmployeeComponent } from './pages/employee/create-employee/create-employee.component';
import { EditEmployeeComponent } from './pages/employee/edit-employee/edit-employee.component';
import { SearchEmployeeComponent } from './pages/employee/search-employee/search-employee.component';
import { LogInComponent } from './pages/log-in/log-in.component';
import { NotFoundComponent } from './pages/not-found/not-found.component';
import { ProfileComponent } from './pages/profile/profile.component';
import { SecureComponent } from './pages/secure/secure.component';
import { TeamsComponent } from './pages/teams/teams.component';

const routes: Routes = [
  { path: 'login', component: LogInComponent  },
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', canActivate: [ AuthGuard ], component: HomeComponent },
  
   // Login Paths:
  
  
   // HTML Paths :
   {
    path: 'home',
    component: HomeComponent, 
    children: [
      {path : 'profile' , component: ProfileComponent , canActivate: [ AuthGuard ] },
      {path : 'createApplication' , component : CreateApplicationComponent , canActivate: [ AuthGuard ]},
      {path : 'addNewCustomer' , component : AddNewCustomerComponent , canActivate : [AuthGuard]},
      {path : 'addExistingCustomer' , component : AddExistingCustomerComponent , canActivate: [ AuthGuard ]},
      {path : 'myApplication' , component : MyApplicationComponent , canActivate: [ AuthGuard ]},
      {path : 'searchApplication' , component : SearchApplicationComponent , canActivate: [ AuthGuard ]},
      {path : 'createEmployee' , component : CreateEmployeeComponent , canActivate: [ AuthGuard ]},
     {path : 'searchEmployee' , component : SearchEmployeeComponent , canActivate: [ AuthGuard ]},
      {path : 'editEmployee' , component : EditEmployeeComponent , canActivate: [ AuthGuard ]},
      {path : 'createBank' , component : CreateBankComponent , canActivate: [ AuthGuard ]},
      {path : 'updateBank' , component : UpdateBankComponent , canActivate: [ AuthGuard ]},
      {path : 'patchBank' , component : PatchUpdateBankComponent , canActivate: [ AuthGuard ]},
      {path : 'team' , component : TeamsComponent ,canActivate: [ AuthGuard ] },
      {path : 'calculator' , component : CalculatorComponent , canActivate: [ AuthGuard ]},
    ]
    
  },
  
  { path: '404', component: NotFoundComponent },
  { path: '**', redirectTo: '404' },
  

  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponent = [ProfileComponent , LogInComponent , CreateApplicationComponent ,
   AddNewCustomerComponent , AddExistingCustomerComponent ,CreateEmployeeComponent , UpdateBankComponent,
    CreateBankComponent ,  SearchApplicationComponent , MyApplicationComponent ,
    SearchEmployeeComponent , EditEmployeeComponent ,  CalculatorComponent , TeamsComponent 
  ]