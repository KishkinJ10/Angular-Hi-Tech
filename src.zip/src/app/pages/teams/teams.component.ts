import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ApiService } from './api.service';
import { Interface } from './Interface';

@Component({
  selector: 'app-teams',
  templateUrl: './teams.component.html',
  styleUrls: ['./teams.component.css']
})
export class TeamsComponent implements OnInit {

  message : boolean = false;

ngOnInit(){
    
}

constructor(private http : HttpClient, private _createService : ApiService) { }

// **** UDEMY METHOD

getCreateTeamAPI(postData : Interface , postForm : NgForm){
  this._createService.getCreateTeam(
    postData.employeeIds,
  postData.teamId,
  postData.teamName,)
  postForm.reset();
    this.message = true;
    
  
  }

  closeAlert(){
    this.message=false;
  }


}
