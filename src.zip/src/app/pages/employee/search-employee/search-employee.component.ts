import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Create } from '../create-employee/create';

@Component({
  selector: 'app-search-employee',
  templateUrl: './search-employee.component.html',
  styleUrls: ['./search-employee.component.css']
})
export class SearchEmployeeComponent implements OnInit {

  empId = localStorage.getItem("employeeId");
  empArray = localStorage.getItem("EmployeeArray");
  specificempId: any ;
  constructor(private http : HttpClient) { }
  
  values = '0';
  onKey(event: any) {
    this.values = event.target.value ;
    console.log(this.values)
    
  }
  searcharray = JSON.parse(JSON.stringify(localStorage.getItem("EmployeesArray")));
  ngOnInit(): void {
    console.log(this.searcharray)
    console.log("Emp array from search employee!!")
    console.log(this.values)
    const specificemployee = this.searcharray.find((el: { email: string | null; }) => el.email === this.values);
   if (specificemployee) {
          this.specificempId  =  localStorage.setItem("empId", specificemployee.employeeId);
         console.log(localStorage.getItem("empId"));
         
       }
  }

  
  getCreateEmployee( city:string,
    country: string,
    dateOfBirth: string,
    email: string,
    employeeAddress: string,
    employeeId: string,
  employeeLevel: string,
    firstName: string,
    lastName: string,
    managerId: string,
    middleName: string,
    password: string,
    phoneNumber:string,
    state: string,
    title: string ){
    const postData : Create = {
      email: email,
      city: '',
      country: '',
      dateOfBirth: '',
      employeeAddress: '',
      employeeId: '',
      employeeLevel: '',
      firstName: '',
      lastName: '',
      managerId: '',
      middleName: '',
      password: '',
      phoneNumber: '',
      state: '',
      title: ''
    }
    return this.http.post<[email : any]>('http://localhost:9900/api/v1/employee',postData).
     subscribe((responseData)=>
    {
      // console.log(responseData);
      // var response = JSON.parse(JSON.stringify(responseData));
      // const specificCustomer = response.body.find((el: { designation: string | null; }) => el.designation=== localStorage.getItem("values"));
      
      //    if (specificCustomer) {
      //      // this.specificCustomerId =  localStorage.setItem("customerId", specificCustomer. customerId);
      //     //  localStorage.setItem("customerId", (response.body.customerId));
      //    }
     
    })
  }

   
 
   
}
