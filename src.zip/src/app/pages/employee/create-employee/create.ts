export interface Create{
  
    city:string,
  country: string,
  dateOfBirth: string,
  email: string,
  employeeAddress: string,
  employeeId: string,
employeeLevel: string,
  firstName: string,
  lastName: string,
  managerId: string,
  middleName: string,
  password: string,
  phoneNumber:string,
  state: string,
  title: string
   
}