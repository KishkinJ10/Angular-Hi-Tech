
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Create } from './create';
import { CreateService } from './create.service';

@Component({
  selector: 'app-create-employee',
  templateUrl: './create-employee.component.html',
  styleUrls: ['./create-employee.component.css']
})
export class CreateEmployeeComponent implements OnInit {
  
  message : boolean = false;

  ngOnInit(){
      
  }
  
  constructor(private http : HttpClient, private _createEmployeeService : CreateService) { }
 
// **** UDEMY METHOD



  getCreateEmployeeAPI(postData : Create , postForm : NgForm){
    this._createEmployeeService.getCreateEmployee(
      postData.city,
      postData.country,
    postData.dateOfBirth,
    postData.email,
    postData.employeeAddress,
    postData.employeeId,
    postData.employeeLevel,
    postData.firstName,
    postData.lastName,
    postData.managerId,
    postData.middleName,
    postData.password,
    postData.phoneNumber,
    postData.state,
    postData.title,
     )

     postForm.reset();
    this.message = true;
    }

    closeAlert(){
      this.message=false;
    }

    

  
}


