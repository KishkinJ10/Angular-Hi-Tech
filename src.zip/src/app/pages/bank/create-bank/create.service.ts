import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Create } from './create';
import { HttpParams } from '@angular/common/http';



@Injectable({
  providedIn: 'root'
})
export class CreateService implements OnInit{
  // ngOnInit(){
  //     this.getFetchBank;
  // }

  private url : string = 'http://localhost:9900/api/v1/bank';
  constructor(private http : HttpClient) { }
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  // getCreateBank() : Observable<Create[]>{
  // return this.http.get<Create[]>(this.url);
  // }


  getCreateBank( 
    bankId: string,
  bankName: string,
  branch: string,
  ifscCode: string,
  passBookNo : string,
       address: {
    addressDetails: string,
    city: string,
    country: string,
    pincode: string,
    state: string
  },
 
   
  ){
    const postData : Create = {
      bankId: bankId,
      bankName: bankName,
      branch: branch,
      ifscCode: ifscCode,
     passBookNo : passBookNo,
      address : address,
    
    }

    return this.http.post('http://localhost:9900/api/v1/bank',postData).subscribe((responseData)=>
    {
      console.log("BANK CREATED!!!")
      console.log(responseData);
    })
  }
   


  // getFetchBank(bankId : string){
  //  const getData : Create = {
  //    bankId: bankId,
  //    bankAddress: '',
  //    bankName: '',
  //    branch: '',
  //    ifscCode: '',
  //    passBookNo: 0
  //  }

  

  //  bankId = "616c07ca9d60c50b84e8b71b";

  //  this.http.get('http://localhost:9900/api/v1/bank/' + bankId
  //  ).subscribe((posts) =>
  //  console.log(posts)
   
  //  )
  // }

  
}
