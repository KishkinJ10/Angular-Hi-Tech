export interface Create{
 
   
  bankId: string,
  bankName: string,
  branch: string,
  ifscCode: string,
  passBookNo : string,
  address: { addressDetails: string; city: string; country: string; pincode: string; state: string; };
}



        
