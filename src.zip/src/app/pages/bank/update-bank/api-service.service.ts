import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Create } from '../create-bank/create';

@Injectable({
  providedIn: 'root'
})
export class ApiServiceService {
  specificBankId: void | undefined;

  constructor(private http : HttpClient) { }

  

  public getSearchBank(
   
    address: {
      addressDetails: string,
    city: string,
      country: string,
      pincode: string,
      state: string
    },
   
    bankId: string,
    bankName: string,
    branch: string,
    ifscCode: string,
     passBookNo : string
    ){
const postData : Create = {
  ifscCode: ifscCode,
  address: {
    addressDetails: '',
    city: '',
    country: '',
    pincode: '',
    state: ''
  },
  bankId: '',
  bankName: '',
  branch: '',
  passBookNo: ''
}
{
return this.http.post('http://localhost:9900/api/v1/bank/search',postData)
.subscribe((responseData)=>
{
  var response = JSON.parse(JSON.stringify(responseData));
  const specificbank = response.body.find((el: { ifscCode: string | null; }) => el.ifscCode=== localStorage.getItem("bankIFSCvalue"));
  
     if (specificbank) {
        this.specificBankId =  localStorage.setItem("BankId", specificbank.bankId);
      //  localStorage.setItem("customerId", (response.body.customerId));
     }
  console.log("Search Bank called from Update bank Component!!")
  console.log(responseData);
  console.log("Bank ifsc code entered is !!")
   console.log(localStorage.getItem("bankIFSCvalue"))

  console.log("Specific Bank id is ")
  console.log(localStorage.getItem("BankId"))
  });  
    }
  }


  


}
