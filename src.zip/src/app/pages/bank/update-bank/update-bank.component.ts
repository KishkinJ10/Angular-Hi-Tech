import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Create } from '../create-bank/create';
import { ApiServiceService } from './api-service.service';

@Component({
  selector: 'app-update-bank',
  templateUrl: './update-bank.component.html',
  styleUrls: ['./update-bank.component.css']
})
export class UpdateBankComponent implements OnInit {

  constructor(private _newApiService : ApiServiceService , private http : HttpClient, public router: Router) { }

  ngOnInit(): void {
    
  }
 
 response : Create[] | undefined ; 
  bankvalue = '0';
  
  onKey(event: any) {
    this.bankvalue = event.target.value ;
    console.log(this.bankvalue)
    
  }


  getSearchBankAPI(postData : Create , postForm : NgForm){
    this._newApiService.getSearchBank(
      postData.address,
       postData.bankId,
      postData.bankName,
      postData.branch,
      postData.ifscCode,
       postData.passBookNo
      
      )
     
   console.log("Search Customer API Called!!");
   postForm.reset();
  
  localStorage.setItem("bankIFSCvalue",this.bankvalue);
  console.log(localStorage.getItem("bankIFSCvalue"))

   this.getBankById();
    }

    public getBankById(){
  return this.http.get<Create[]>('http://localhost:9900/api/v1/bank/' + localStorage.getItem("BankId"))

  
  .subscribe((responseData : Create[])=>
  {
    const x = JSON.parse(JSON.stringify(responseData));
    let arr: any[] = [];  
    arr.push(x.body)   
 this.response = arr;
console.log(this.response)
         });  

}



    }
  

