import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Create } from './create';

@Injectable({
  providedIn: 'root'
})
export class CreateService {

  private url : string = 'http://localhost:9900/api/v1/application';
  constructor(private http : HttpClient) { }

  custId : any = localStorage.getItem("customerId");
  empId : any = localStorage.getItem("employeeId");

  getCreateApplication(
    amountApplied: 0,
    applicationId: string,
    applicationState: string,
      comment: string,
    commentBy: string,
    commentId: string,
    documentId: string,
    link: string,
    submitted: true,
    title: string,
    employee: string,
    formNumber: string,
    location: string,
    los: string,
    priority: 0,
    receivedDate: string,
    team: string,
    tenure: 0 ,
    customerId: string,
      employeeId: string
    
  
    ){
    const postData : Create = {
     
    amountApplied: 0,
    applicationId: applicationId,
    applicationState: applicationState,
      comment: comment,
    commentBy: commentBy,
    commentId: commentId,
    documentId: documentId,
    link: link,
    submitted: true,
    title: title,
    employee: employee,
    formNumber: formNumber,
    location: location,
    los: los,
    priority: 0,
    receivedDate: receivedDate,
    team: team,
    tenure: 0,
    customerId: this.custId,
      employeeId: this.empId
  
    }
    return this.http.post('http://localhost:9900/api/v1/application',postData).subscribe((responseData)=>
    {
      var response = JSON.parse(JSON.stringify(responseData));
      console.log(responseData);
      console.log("Customer Id is!!")
      console.log(this.custId)
      console.log("Employee Id from application is:")
      console.log(this.empId)
    })
  }

  
}
