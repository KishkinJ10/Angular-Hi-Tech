import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {map} from 'rxjs/operators';
import { App } from '../add-new-customer/app';

@Injectable({
  providedIn: 'root'
})
export class ApiServiceService {

  constructor(private http : HttpClient) { }

  custId = localStorage.getItem("customerId");
    phoneId = localStorage.getItem("values");
    specificCustomerId : any;


  public getSeacrhCustomer(
    aadharId: string,
    emails:  string ,
    pan: string,
    phoneNumber: string
    ){
const postData : App = {
  aadharId: aadharId,
  emails: emails,
  pan: pan,
  phoneNumber: phoneNumber,
  address: '',
  city: '',
  country: '',
  customerId: '',
  dateOfBirth: '',
  designation: '',
  firstName: '',
  jobProfile: '',
  lastName: '',
  middleName: '',
  monthlySalary: '',
  passbooks: '',
  pinCode: '',
  state: '',
  title: ''
}
{
return this.http.post('http://localhost:9900/api/v1/customer/search',postData



)
// .pipe(map(response => {
//   const getArray = [];
//   for(this.phoneId in response){
//     if(response.hasOwnProperty(this.custId)){
//   getcustArray.push({ ...response[this.custId] , id : this.custId});
    
// }
//   }
  
//   return getcustArray;

// }))
.subscribe((responseData)=>
{
  var response = JSON.parse(JSON.stringify(responseData));
  const specificCustomer = response.body.find((el: { designation: string | null; }) => el.designation=== localStorage.getItem("values"));
  
     if (specificCustomer) {
        this.specificCustomerId =  localStorage.setItem("customerId", specificCustomer.customerId);
      //  localStorage.setItem("customerId", (response.body.customerId));
     }
  console.log("Search Customer called from Existing Component!!")
  console.log(responseData);
   console.log(localStorage.getItem("values"))
  console.log(this.phoneId)
  console.log("Specific customer id is ")
  console.log(localStorage.getItem("customerId"))
  });  
    }
  }
}
