export interface Search {

    customerId: string,
     employeeId: string

}