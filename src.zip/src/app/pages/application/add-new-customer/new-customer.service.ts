import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { App } from './app';
import { map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class NewApplicationService {


 
  

  private url : string = 'http://localhost:9900/api/v1/customer';
  localItem : any ;
  

  constructor(private http : HttpClient) {}


  
  getCreateCustomer(aadharId: string,
    address: string,
    city: string,
    country: string,
    customerId: string,
    dateOfBirth: string,
    designation: string,
    emails:  string ,
    firstName: string,
    jobProfile: string,
    lastName: string,
    middleName: string,
    monthlySalary: string,
    pan: string,
    passbooks: string,
    phoneNumber: string,
    pinCode: string,
    state: string,
    title: string
   ){
    const postData : App = {
      aadharId: aadharId,
      address: address,
      city: city,
      country: country,
      customerId: customerId,
      dateOfBirth: dateOfBirth,
      designation: designation,
      emails:  emails,
      firstName: firstName,
      jobProfile: jobProfile,
      lastName: lastName,
      middleName: middleName,
      monthlySalary: monthlySalary,
      pan: pan,
      passbooks: passbooks,
      phoneNumber: phoneNumber,
      pinCode: pinCode,
      state: state,
      title: title
    
  }
 
    return this.http.post('http://localhost:9900/api/v1/customer',postData)
    .subscribe((responseData)=>
    {
     var response = JSON.parse(JSON.stringify(responseData));
      localStorage.setItem("customerId", (response.body.customerId));
     
      console.log(response)
      console.log(response.body.customerId)
      console.log("LOCAL ITEM")
      this.localItem = localStorage.getItem("customerId")
      console.log(this.localItem)
      
      
     
    })
  }

  ExtractCustomerId(){
    console.log(this.localItem)
   return this.localItem;
  }

 

// private extractData(res: Response) : any {
//    let body = res.json();
//    return body.data || { };
// }
 
  
}


