export interface App {
       
    
        aadharId: string,
        address: string,
        city: string,
        country: string,
        customerId: string,
        dateOfBirth: string,
        designation: string,
        emails:  string ,
        firstName: string,
        jobProfile: string,
        lastName: string,
        middleName: string,
        monthlySalary: string,
        pan: string,
        passbooks: string,
        phoneNumber: string,
        pinCode: string,
        state: string,
        title: string
      

}
