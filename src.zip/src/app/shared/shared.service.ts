import { EventEmitter, Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject, Subscription } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
  // private subject = new Subject<any>();
   private subject = new BehaviorSubject<any>(null);
   clickEventSubscription : Subscription | undefined;
  

    sendClickEvent(){
      this.subject.next;
    }

    getClickEvent():Observable<any>{
      return this.subject.asObservable();
    }

  

}
