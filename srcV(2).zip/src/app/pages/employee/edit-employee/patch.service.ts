import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Create } from '../create-employee/create';

@Injectable({
  providedIn: 'root'
})
export class PatchService {

  empId = localStorage.getItem("empId");
  constructor(private http : HttpClient) { }

  public getPatchEployee(
   
    city:string,
  country: string,
  dateOfBirth: string,
  email: string,
  employeeAddress: string,
  employeeId: string,
employeeLevel: string,
  firstName: string,
  lastName: string,
  managerId: string,
  middleName: string,
  password: string,
  phoneNumber:string,
  state: string,
  title: string
    ){
const postData : Create = {
  city : city,
  country:country,
  dateOfBirth:dateOfBirth,
  email:email,
  employeeAddress:employeeAddress,
  employeeId:employeeId,
employeeLevel:employeeLevel,
  firstName:firstName,
  lastName:lastName,
  managerId:managerId,
  middleName : middleName,
  password:password,
  phoneNumber : phoneNumber,
  state : state,
  title : title
}
{
return this.http.patch('http://localhost:9900/api/v1/employee/' + this.empId,postData)
.subscribe((responseData)=>
{
  console.log("Patch Employee API CALLED!!")
  console.log(responseData);
  
  });  
    }
  }
}
