import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AlertService } from 'src/app/alert/alert.service';
import { Create } from '../create-employee/create';
import { PatchService } from './patch.service';

@Component({
  selector: 'app-edit-employee',
  templateUrl: './edit-employee.component.html',
  styleUrls: ['./edit-employee.component.css']
})
export class EditEmployeeComponent implements OnInit {

 
  constructor(private patchService : PatchService,  public alertService: AlertService ,  public router: Router) { }

  ngOnInit(): void {
    console.log(localStorage.getItem("empId"));
  }

  options = {
    autoClose: true,
    keepAfterRouteChange: false
};

  getPatchEmployeeAPI(postData : Create , postForm : NgForm){
    this.patchService.getPatchEployee(
      postData.city,
      postData.country,
      postData.dateOfBirth,
      postData.email,
      postData.employeeAddress,
      postData.employeeId,
     postData.employeeLevel,
      postData.firstName,
      postData.lastName,
     postData. managerId,
      postData.middleName,
      postData.password,
      postData.phoneNumber,
      postData.state,
      postData.title
      )
  console.log("Patch Employee called from ts file!!");
   postForm.reset();

   setTimeout(() => {
    this.router.navigate(['/home/searchEmployee']);
}, 5000);  //5s
    }

 

}
