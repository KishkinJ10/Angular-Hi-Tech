import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/internal/operators/map';
import { Create } from './create';

@Injectable({
  providedIn: 'root'
})
export class CreateService {

  

  private url : string = 'http://localhost:9900/api/v1/employee';
  
  getemployeeArray : any = [];
  constructor(private http : HttpClient) { }
    


  getCreateEmployee( city:string,
    country: string,
    dateOfBirth: string,
    email: string,
    employeeAddress: string,
    employeeId: string,
  employeeLevel: string,
    firstName: string,
    lastName: string,
    managerId: string,
    middleName: string,
    password: string,
    phoneNumber:string,
    state: string,
    title: string ){
    const postData : Create = {
      city:city,
      country: country,
      dateOfBirth: dateOfBirth,
      email: email,
      employeeAddress: employeeAddress,
      employeeId: employeeId,
     employeeLevel: employeeLevel,
      firstName: firstName,
      lastName: lastName,
      managerId: managerId,
      middleName: middleName,
      password: password,
      phoneNumber:phoneNumber,
      state: state,
      title: title}
    return this.http.post<{[employeeId : string] : Create}>('http://localhost:9900/api/v1/employee',postData).
    pipe(map(response => {
      var res = JSON.parse(JSON.stringify(response))
        
      
       console.log(res)
        for(const employeeId in res){
          if(res.hasOwnProperty(employeeId)){
            this.getemployeeArray.push({ ...res[employeeId] , id: employeeId});
            }
           if(res.hasOwnProperty(email)){
            this.getemployeeArray.push({...res[email] , id:email });
           } 
        }
        
        console.log("Employee Id Array from Create employee Service " , this.getemployeeArray)
        localStorage.setItem("employees", JSON.stringify(this.getemployeeArray));
      })).
    
    // When I am creating employee I am saving all the employee emails in an array cause 
    // since employee emails are unique 
    // Here I am saving the employee email array in local storage in string forms
  
     subscribe((responseData)=>
    {
      const emp = JSON.parse(localStorage.getItem("employees") || "[]");
      console.log(emp);
      // this.getemployeeEmailArray.push(response);
      
      // console.log("Get employee Array")
      // console.log(this.getemployeeEmailArray)
      // var employeesArray = (this.getemployeeEmailArray);
      // localStorage.setItem("EmployeesArray",employeesArray);
      //   console.log("EMP ARRAY IS!!!" + localStorage.getItem("EmployeeArray"));


      // var response = JSON.parse(JSON.stringify(responseData));
      // localStorage.setItem("employeeId", (response.body.employeeId));
     
      // console.log(response)
      // console.log(response.body.customerId)
      // console.log("LOCAL ITEM")
      // this.localItem = localStorage.getItem("employeeId")
      // console.log("EmployeeId is ~!!!!!!!!")
      // console.log(this.localItem)
      
     
    })
  }

  
}
