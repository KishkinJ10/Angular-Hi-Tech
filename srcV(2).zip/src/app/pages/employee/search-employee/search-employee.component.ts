import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Alert, AlertService } from 'src/app/alert';
import { Create } from '../create-employee/create';

@Component({
  selector: 'app-search-employee',
  templateUrl: './search-employee.component.html',
  styleUrls: ['./search-employee.component.css']
})
export class SearchEmployeeComponent implements OnInit {

  
 
  specificempId : any ;
  response : any =  [];

  editEmployeeFlag: boolean | undefined;

  constructor(private http : HttpClient ,  public router: Router , public alertService: AlertService) {  }
  

  options = {
    autoClose: true,
    keepAfterRouteChange: false
};

  values = '0';

  onKey(event: any){
    this.values = event.target.value ;
    console.log(this.values)
  }
  
  ngOnInit(): void {
   
   this.editEmployeeFlag = true;
 
  }

  clickEmpId(){
    const empArray =  JSON.parse(localStorage.getItem("employees") || "[]");
    console.log(empArray);
     // var response = JSON.parse(JSON.stringify(responseData));
    const specificemp = empArray.find((el: { email: string | null; }) => el.email === this.values) ;
     
        if (specificemp) {
          // this.specificempId =  localStorage.setItem("empId", specificemp.employeeId);
        // console.log(" Search Employee id is : " );
        // console.log(localStorage.getItem("empId"))
        // console.log(specificemp.employeeId)
        this.specificempId = specificemp.employeeId;
        localStorage.setItem("empId" , this.specificempId);
        this.getEmployeeById(this.specificempId);
        }else{
          
            this.alertService.error('Employee does not exist !!', this.options)

       setTimeout(() => {
        this.router.navigate(['/home/searchEmployee'])
        .then(() => {
          window.location.reload();
        });
       }, 2000);
        }
        this.editEmployeeFlag = false;
        
  }

  public clearEmailInput(postForm : NgForm){
    this.router.navigate(['/home/updateBank'])
    .then(() => {
      window.location.reload();
    });
  }



  public getEmployeeById(emp : string){
    return this.http.get('http://localhost:9900/api/v1/employee/' + emp)
    .subscribe((responseData) => {
      console.log("EmployeeId is" + emp )
      const x = JSON.parse(JSON.stringify(responseData));
    let arr: any[] = [];  
    arr.push(x.body)   
 this.response = arr;
console.log(this.response)
    });
  }




   
}
