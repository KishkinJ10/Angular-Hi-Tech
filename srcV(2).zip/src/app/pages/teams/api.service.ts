import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Interface } from './Interface'

@Injectable({
  providedIn: 'root'
})
export class ApiService {


  private url : string = 'http://localhost:9900/api/v1/team';
  constructor(private http : HttpClient) { }


  getCreateTeam( employeeIds:string,
    teamId: string,
    teamName: string ){
    const postData : Interface = {
      employeeIds : employeeIds,
      teamId : teamId,
      teamName : teamName
      }
    return this.http.post('http://localhost:9900/api/v1/team',postData).subscribe((responseData)=>
    {
      console.log(responseData);
    })
  }

}
