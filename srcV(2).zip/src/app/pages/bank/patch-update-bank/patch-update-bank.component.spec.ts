import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PatchUpdateBankComponent } from './patch-update-bank.component';

describe('PatchUpdateBankComponent', () => {
  let component: PatchUpdateBankComponent;
  let fixture: ComponentFixture<PatchUpdateBankComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PatchUpdateBankComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PatchUpdateBankComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
