import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Create } from '../create-bank/create';
import { PatchApiService } from './patch-api.service';
import { AlertService } from 'src/app/alert/alert.service';
@Component({
  selector: 'app-patch-update-bank',
  templateUrl: './patch-update-bank.component.html',
  styleUrls: ['./patch-update-bank.component.css']
})
export class PatchUpdateBankComponent implements OnInit {

  constructor(private patchService : PatchApiService ,  public alertService: AlertService) { }

  ngOnInit(): void {
    console.log("Bank Id is : ");
  console.log(localStorage.getItem("BankId"))
  }

  options = {
    autoClose: true,
    keepAfterRouteChange: false
};

  getPatchBankAPI(postData : Create , postForm : NgForm){
    this.patchService.getPatchBank(
      postData.address,
       postData.bankId,
      postData.bankName,
      postData.branch,
      postData.ifscCode,
       postData.passBookNo,
      postData.city
      )
  console.log("Patch Bank called from ts file!!");
   postForm.reset();
    }


}
