import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Observable } from 'rxjs';
import { AlertService } from 'src/app/alert/alert.service';
import { Create } from './create';
import { CreateService } from './create.service';

@Component({
  selector: 'app-create-bank',
  templateUrl: './create-bank.component.html',
  styleUrls: ['./create-bank.component.css']
})
export class CreateBankComponent implements OnInit{

 

  options = {
    autoClose: true,
    keepAfterRouteChange: false
};
  

  //   creates: any;
 
  // constructor(private _createService : CreateService){}

  // // ngOnInit(){
  // //     this._createService.getCreateBank().subscribe( res => {
  // //       this.creates = res;
  // //       console.log("Create Bank API Called!!!");
  // //     },
  // //     err=> {
  // //       console.log(err);
  // //     }
  // //     );

  // // }
  message : boolean = false;

  ngOnInit(){
      
  }
    
  // getCreateBankFromApi(){
  //   return this._createService.getCreateBank().subscribe((response) => {
  //     console.log("Bank API");
  //     this.creates = response;
  //   }, (error) => {
  //     console.log('Error is ',error);
  //   }
  //   )
  // }
  
 
  constructor(private http : HttpClient, private _createService : CreateService , public alertService: AlertService) { }
 

//   getCreateBankFromApi(data: any){
// return this.http.post('http://localhost:8080/api/v1/bank',data).subscribe((result)=> {
//   console.warn('Result',result);
// })
//   }


// **** UDEMY METHOD
loadedPost = [];


  getCreateBankAPI(postData : Create,postForm : NgForm){
    this._createService.getCreateBank(
      postData.bankId,
      postData.bankName,
      postData.branch,
      postData.ifscCode,
     postData.passBookNo,
      postData.address,
      postData.city
   
   )
   console.log("Create Bank form reset")
   postForm.reset();
    
    }

   
    

    // getFetchBankAPI(postData : Create ){
    //   this._createService.getFetchBank(postData.bankId)
      
    // }
    

  // getCreateBank(){
  //   console.log('Submitted!!');
  // }
 
}
