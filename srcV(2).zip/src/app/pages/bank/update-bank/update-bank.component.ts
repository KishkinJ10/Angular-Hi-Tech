import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { SharedService } from 'src/app/shared/shared.service';
import { Create } from '../create-bank/create';
import { ApiServiceService } from './api-service.service';

@Component({
  selector: 'app-update-bank',
  templateUrl: './update-bank.component.html',
  styleUrls: ['./update-bank.component.css']
})
export class UpdateBankComponent implements OnInit {

  constructor(private _newApiService : ApiServiceService ,
     private http : HttpClient, public router: Router ) { 
  
  }

  
  // This is for button disabling
  seeBankDetailFlag: boolean | undefined;
goToUpdateBankFlag: boolean | undefined;

  ngOnInit(): void{
     this.seeBankDetailFlag = true;
     this.goToUpdateBankFlag = true;
}
 
 response : Create[] | undefined ; 
  bankvalue = '0';
  
  onKey(event: any) {
    this.bankvalue = event.target.value ;
    console.log(this.bankvalue)
    
  }


  getSearchBankAPI(postData : Create , postForm : NgForm){
    this._newApiService.getSearchBank(
      postData.address,
       postData.bankId,
      postData.bankName,
      postData.branch,
      postData.ifscCode,
       postData.passBookNo,
      postData.city
      )
     
   console.log("Search Customer API Called!!");
   postForm.reset();
  
  localStorage.setItem("bankIFSCvalue",this.bankvalue);
  console.log(localStorage.getItem("bankIFSCvalue"))

   
    }
    // This is for button disabling
    getBankDetails(): void{
      this.seeBankDetailFlag = false;
   }

    public clearIfscInput(postForm : NgForm){
     this.router.navigate(['/home/updateBank'])
        .then(() => {
          window.location.reload();
        });
}
  

    public getBankById(){
      // This is for button disabling
      this.seeBankDetailFlag = true;
      this.goToUpdateBankFlag = false;
  return this.http.get<Create[]>('http://localhost:9900/api/v1/bank/' + localStorage.getItem("BankId"))

  
  .subscribe((responseData : Create[])=>
  {
    const x = JSON.parse(JSON.stringify(responseData));
    let arr: any[] = [];  
    arr.push(x.body)   
 this.response = arr;
console.log(this.response)
         });  

}





    }
  

