import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { AlertService } from 'src/app/alert/alert.service';
import { SharedService } from 'src/app/shared/shared.service';
import { Create } from '../create-bank/create';

@Injectable({
  providedIn: 'root'
})
export class ApiServiceService {
  specificBankId: void | undefined;

       
  
  options = {
    autoClose: true,
    keepAfterRouteChange: false
};


  constructor(private http : HttpClient , public alertService: AlertService ,public router: Router  ) {
    
 }

  

  public getSearchBank(
   
    address : string,
  city : string,
   
    bankId: string,
    bankName: string,
    branch: string,
    ifscCode: string,
     passBookNo : string
    ){
const postData : Create = {
  ifscCode: ifscCode,
  address: '',
  city : '',
  bankId: '',
  bankName: '',
  branch: '',
  passBookNo: ''
}
{
return this.http.post('http://localhost:9900/api/v1/bank/search',postData)
.subscribe((responseData)=>
{
  var response = JSON.parse(JSON.stringify(responseData));
  const specificbank = response.body.find((el: { ifscCode: string | null; }) => el.ifscCode=== localStorage.getItem("bankIFSCvalue"));
  
     if (specificbank) {
        this.specificBankId =  localStorage.setItem("BankId", specificbank.bankId);
      //  localStorage.setItem("customerId", (response.body.customerId));
     }else{

      this.alertService.error('Bank does not exist !!', this.options)

       setTimeout(() => {
        this.router.navigate(['/home/updateBank'])
        .then(() => {
          window.location.reload();
        });
       }, 2000);
      
     
     }
  console.log("Search Bank called from Update bank Component!!")
  console.log(responseData);
  console.log("Bank ifsc code entered is !!")
   console.log(localStorage.getItem("bankIFSCvalue"))

  console.log("Specific Bank id is ")
  console.log(localStorage.getItem("BankId"))
  });  
    }
  }


  


}
