import { HttpClient, HttpParams } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Subscription } from 'rxjs';
import { map } from 'rxjs/operators';
import { SharedService } from 'src/app/shared/shared.service';
import { App } from '../add-new-customer/app';
import { NewApplicationService } from '../add-new-customer/new-customer.service';
import { Create } from './create';
import { CreateService } from './create.service';



@Component({
  providers :[SharedService],
  selector: 'app-create-application',
  templateUrl: './create-application.component.html',
  styleUrls: ['./create-application.component.css']
})
export class CreateApplicationComponent implements OnInit {

 load : any =  [];
 newAttribute: any = {};
 custId = localStorage.getItem("customerId");
 empId : any = localStorage.getItem("employeeId");

  message : boolean = false;

  //  clickEventSubscription : Subscription;
//  // This is for calling getFetchAPI function from add new customer
  constructor(private http : HttpClient, private _createService : CreateService, private shared : SharedService) { 
  //  this.clickEventSubscription = this.shared.getClickEvent().subscribe(() => {
  //    console.log("Click Event subscription")
  //   this.FetchCustomer();
  //   })

    if (this.shared.clickEventSubscription==undefined) {    
      this.shared.clickEventSubscription = this.shared.    
      getClickEvent().subscribe(() => {
        console.log("Click Event subscription")
       this.FetchCustomer();
       })
    }    

  }
  
  
 ngOnInit(){
  //  console.log("Customer Id called!!")
  // console.log(this.custId);

  // console.log("Customer Fetched!!!!!!!!!!!11")
  // this.http.get<{[customerId : string] : App}>('http://localhost:9900/api/v1/customer/'+this.custId,
  // ).pipe(map(response => {
  //   const getcustArray = [];
  //   for(this.custId in response){
  //     if(response.hasOwnProperty(this.custId)){
  //       getcustArray.push({ ...response[this.custId] , id : this.custId});

  //     }
  //   }
  //   return getcustArray;

  // }))
  // .subscribe((responseData)=>
  // {
  //   this.load = responseData ;
   
  // });
  // console.log("Fetch Customer Finished!!!!!!******");

  // console.log("Customer Fetched!!!!!!!!!!!11")
  //     this.http.get<{[customerId : string] : App}>('http://localhost:9900/api/v1/customer/' + this.custId
  //     ).pipe(map(response => {
  //       const getcustArray = [];
  //       for(const customerId in response){
  //         if(response.hasOwnProperty(customerId)){
  //           getcustArray.push({ ...response[customerId] , id : customerId});
    
  //         }
  //       }
  //       return getcustArray;
    
  //     }))
  //     .subscribe((responseData)=>
  //     {
  //       this.load = responseData ;
       
  //     });
  //     console.log("Fetch Customer Finished!!!!!!******");

   
 }
  

 
 
  


// **** UDEMY METHOD



  getCreateApplicationAPI(postData : Create , postForm : NgForm){
    this._createService.getCreateApplication(
      postData.amountApplied,
      postData.applicationId,
      postData.applicationState,
        postData.comment,
      postData.commentBy,
      postData.commentId,
      postData.documentId,
      postData.link,
      postData.submitted,
      postData.title,
      postData.employee,
      postData.formNumber,
      postData.location,
      postData.los,
      postData.priority,
      postData.receivedDate,
      postData.team,
      postData.tenure,
      postData.customerId,
      postData.employeeId
     
      )

      postForm.reset();
    this.message = true;
  
    }

    

    closeAlert(){
      this.message=false;
    }

   
    

    //  public FetchCustomer(customerId: string){
    //   console.log("Customer Fetched!!!!!!!!!!!11")
    //   this.http.get<{[customerId : string] : App}>('http://localhost:9900/api/v1/customer/'+this.custId,
    //   ).pipe(map(response => {
    //     const getcustArray = [];
    //     for( customerId in response){
    //       if(response.hasOwnProperty(customerId)){
    //         getcustArray.push({ ...response[customerId] , id : customerId});
    
    //       }
    //     }
    //     return getcustArray;
    
    //   }))
    //   .subscribe((responseData)=>
    //   {
    //     this.load = responseData ;
       
    //   });
    //   console.log("Fetch Customer Finished!!!!!!******");
      
    //  }

     public FetchCustomer(){
      console.log("Customer Fetched!!!!!!!!!!!11")
      this.http.get<{[customerId : string] : App}>('http://localhost:9900/api/v1/customer/'+this.custId,
      ).pipe(map(response => {
        const getcustArray = [];
        for(this.custId in response){
          if(response.hasOwnProperty(this.custId)){
            getcustArray.push({ ...response[this.custId] , id : this.custId});
            
          }
        }
        
        return getcustArray;
    
      })).pipe(map(response => {
        const getempArray = [];
        for(this.empId in response){
          if(response.hasOwnProperty(this.empId)){
            getempArray.push({ ...response[this.empId] , id : this.empId});
            
          }
        }
        
        return getempArray;
    
      }))
      .subscribe((responseData)=>
      {
        this.load = responseData ;
       
      });
      console.log("Fetch Customer Finished!!!!!!******");
      
     }
  
    


  
 

}


