import { TestBed } from '@angular/core/testing';

import { SearchSerService } from './search-ser.service';

describe('SearchSerService', () => {
  let service: SearchSerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SearchSerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
