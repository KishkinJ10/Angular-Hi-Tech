import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Search } from './search';

@Injectable({
  providedIn: 'root'
})
export class SearchSerService {

  
  private url : string = 'http://localhost:9900/api/v1/application/search';
  constructor(private http : HttpClient) { }

  

  getSearchApplication(
    customerId: string,
    employeeId: string
  
    ){
    const postData : Search = {
     
    customerId: customerId,
      employeeId: employeeId
  
    }
    return this.http.post('http://localhost:9900/api/v1/application/search',postData).subscribe((responseData)=>
    {
     
      console.log(responseData);
    })
  }
}
