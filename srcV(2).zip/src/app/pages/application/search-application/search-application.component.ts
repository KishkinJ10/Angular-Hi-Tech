import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Search } from './search';
import { SearchSerService } from './search-ser.service';

@Component({
  selector: 'app-search-application',
  templateUrl: './search-application.component.html',
  styleUrls: ['./search-application.component.css']
})
export class SearchApplicationComponent implements OnInit {

  constructor(private _searchService : SearchSerService) { }

  ngOnInit(): void {
  }

  getSearchApplicationsAPI(postData : Search , postForm : NgForm){
    this._searchService.getSearchApplication(
      postData.customerId,
      postData.employeeId
    )
    postForm.reset();
}

}
