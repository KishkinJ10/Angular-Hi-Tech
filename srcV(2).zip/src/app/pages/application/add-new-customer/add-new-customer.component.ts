
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { App } from './app';
import { HttpClient } from '@angular/common/http'

import { NewApplicationService } from './new-customer.service';
import { SharedService } from 'src/app/shared/shared.service';
import { AlertService } from 'src/app/alert/alert.service';


@Component({
  providers :[SharedService],
  selector: 'app-add-new-customer',
  templateUrl: './add-new-customer.component.html',
  styleUrls: ['./add-new-customer.component.css']
 
})
export class AddNewCustomerComponent implements OnInit {
  
  li: any;
  lis= [];

   
  options = {
    autoClose: true,
    keepAfterRouteChange: false
};

  
    
  

 
  constructor(private _newApplicationService : NewApplicationService , public router: Router  , 
    private http : HttpClient  , private shared : SharedService , public alertService: AlertService){
      
    }

  ngOnInit(){
     
  }
  
  callMe(){
    console.log("CALLLLLL MEEEEEEEEEEEEEEE")
    this.alertService.success('New Customer Created!!', this.options) 
    setTimeout(() => {
      this.router.navigate(['/home/createApplication'])
     }, 2000);
   
     this.shared.sendClickEvent();
    console.log("CALLL MMMEEEE FINISHED")
    }

  message : boolean = false;

  getCreateCustomerAPI(postData : App , postForm : NgForm){
    this._newApplicationService.getCreateCustomer(
      postData.aadharId,
      postData.address,
      postData.city,
      postData.country,
      postData.customerId,
      postData.dateOfBirth,
      postData.designation,
      postData.emails, 
      postData.firstName,
      postData.jobProfile,
      postData.lastName,
      postData.middleName,
      postData.monthlySalary,
      postData.pan,
      postData.passbooks,
      postData.phoneNumber,
      postData.pinCode,
      postData.state,
      postData.title
   )
   console.log("Create Customer API Called!!");
   
   postForm.reset();
   this.message = true;
   
    }

  

    
  
    // getFetchCustomer(customerId : string){
    //   const getData : App = {
    //     customerId: customerId,
    //     aadharId: '',
    //     address: '',
    //     city: '',
    //     country: '',
    //     dateOfBirth: '',
    //     designation: '',
    //     emails: '',
    //     firstName: '',
    //     jobProfile: '',
    //     lastName: '',
    //     middleName: '',
    //     monthlySalary: '',
    //     pan: '',
    //     passbooks: '',
    //     phoneNumber: '',
    //     pinCode: '',
    //     state: '',
    //     title: ''
    //   }
   
     
   
    //   customerId = this.getCustomerId();
   
    //   this.http.get('http://localhost:9900/api/v1/application' + customerId
    //   ).subscribe((responseData)=>
    //   {
    //     this.li = responseData;
    //     console.log(responseData);
    //   })
    //  }
  

    
  
   
    closeAlert(){
      this.message=false;
    }


   

    // CALLING METHOD FROM DIFFERENT COMPONENT::::::::::::::

    // call(){
    //   let creatApplicationobj = new CreateApplicationComponent();
    //   creatApplicationobj.getFetchCustomer();
    // }
    

    

    


    

 

  

}
  

