import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { App } from '../add-new-customer/app';
import { ApiServiceService } from './api-service.service';

@Component({
  selector: 'app-add-existing-customer',
  templateUrl: './add-existing-customer.component.html',
  styleUrls: ['./add-existing-customer.component.css']
})
export class AddExistingCustomerComponent implements OnInit {
 
  constructor(private http : HttpClient ,private _newApiService : ApiServiceService , public router: Router) {}

  ngOnInit(): void {
  }

  values = '0';

  onKey(event: any) {
    this.values = event.target.value ;
    console.log(this.values)
    
  }


  getSearchCustomerAPI(postData : App , postForm : NgForm){
    this._newApiService.getSeacrhCustomer(
      postData.aadharId,
      postData.emails, 
      postData.pan,
      postData.phoneNumber,
      postData.designation
      )
   console.log("Search Customer API Called!!");
   localStorage.setItem("values",this.values);
   postForm.reset();
  //   localStorage.setItem("phoneNumber" , postData.phoneNumber);
   console.log("PHONE NUMBER IS!!!!")
  // console.log(this.values)
 
  console.log(localStorage.getItem("values"))
  
    }

    

    

 
}
