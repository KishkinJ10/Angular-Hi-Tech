import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-existing-customer',
  templateUrl: './add-existing-customer.component.html',
  styleUrls: ['./add-existing-customer.component.css']
})
export class AddExistingCustomerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
