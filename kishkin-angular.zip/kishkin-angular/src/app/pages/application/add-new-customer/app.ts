export interface App {
    applicationState: string;
    link: string;
    title: string;
    receivedDate: string;
    amountApplied: number;
    applicationId: string;
    comment: string;
    commentBy: string;
    commentId: string;
    documentId: string;
    submitted: true;
    employee: string;
    formNumber: number;
    location: string;
    los: string;
    priority: number;
    team: string;
    tenure: number;
}
