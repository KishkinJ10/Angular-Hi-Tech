
import { Component, OnInit } from '@angular/core';

import { NewApplicationService } from './new-application.service';



@Component({
  selector: 'app-add-new-customer',
  templateUrl: './add-new-customer.component.html',
  styleUrls: ['./add-new-customer.component.css']
})
export class AddNewCustomerComponent implements OnInit {

 public newApp: any[] = [];
 
  constructor(private _newApplicationService : NewApplicationService){}

  ngOnInit(){
      this._newApplicationService.getCreateApplication().subscribe( res => {
        this.newApp = res;
        console.log("New Application API Called!!")
      });
  }
  

  
  
}
