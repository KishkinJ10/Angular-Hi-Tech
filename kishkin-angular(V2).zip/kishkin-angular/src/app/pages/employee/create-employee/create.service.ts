import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Create } from './create';

@Injectable({
  providedIn: 'root'
})
export class CreateService {

  

  private url : string = 'http://localhost:9900/api/v1/employee';
  constructor(private http : HttpClient) { }


  getCreateEmployee( city:string,
    country: string,
    dateOfBirth: string,
    email: string,
    employeeAddress: string,
    employeeId: string,
  employeeLevel: string,
    firstName: string,
    lastName: string,
    managerId: string,
    middleName: string,
    password: string,
    phoneNumber:string,
    state: string,
    title: string ){
    const postData : Create = {
      city:city,
      country: country,
      dateOfBirth: dateOfBirth,
      email: email,
      employeeAddress: employeeAddress,
      employeeId: employeeId,
    employeeLevel: employeeLevel,
      firstName: firstName,
      lastName: lastName,
      managerId: managerId,
      middleName: middleName,
      password: password,
      phoneNumber:phoneNumber,
      state: state,
      title: title}
    return this.http.post('http://localhost:9900/api/v1/employee',postData).subscribe((responseData)=>
    {
      console.log(responseData);
    })
  }

  
}
