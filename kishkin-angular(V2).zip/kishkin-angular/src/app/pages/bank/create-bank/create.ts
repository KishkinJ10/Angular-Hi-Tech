export interface Create{
  
    bankAddress: string;
    bankId: string;
  bankName: string;
  branch: string;
  ifscCode: string;
  passBookNo : number
   
}
        
        
