import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddExistingCustomerComponent } from './add-existing-customer.component';

describe('AddExistingCustomerComponent', () => {
  let component: AddExistingCustomerComponent;
  let fixture: ComponentFixture<AddExistingCustomerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddExistingCustomerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddExistingCustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
