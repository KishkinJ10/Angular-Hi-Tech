export interface Create {

    amountApplied: 0,
    applicationId: string,
    applicationState: string,
      comment: string,
    commentBy: string,
    commentId: string,
    documentId: string,
    link: string,
    submitted: true,
    title: string,
    employee: string,
    formNumber: string,
    location: string,
    los: string,
    priority: 0,
    receivedDate: string,
    team: string,
    tenure: 0,
    customerId:string,
    employeeId: string
    

}