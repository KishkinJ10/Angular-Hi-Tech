import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Create } from './create';
import { CreateService } from './create.service';



@Component({
  selector: 'app-create-application',
  templateUrl: './create-application.component.html',
  styleUrls: ['./create-application.component.css']
})
export class CreateApplicationComponent implements OnInit {

  message : boolean = false;
 ngOnInit(){
      
  }
 
  constructor(private http : HttpClient, private _createService : CreateService) { }
 


// **** UDEMY METHOD



  getCreateApplicationAPI(postData : Create , postForm : NgForm){
    this._createService.getCreateApplication(
      postData.amountApplied,
      postData.applicationId,
      postData.applicationState,
        postData.comment,
      postData.commentBy,
      postData.commentId,
      postData.documentId,
      postData.link,
      postData.submitted,
      postData.title,
      postData.employee,
      postData.formNumber,
      postData.location,
      postData.los,
      postData.priority,
      postData.receivedDate,
      postData.team,
      postData.tenure,
     
      )

      postForm.reset();
    this.message = true;
  
    }

    closeAlert(){
      this.message=false;
    }

    getSearchApplications(postData : Create){
        this._createService.getSearchApplication(
          postData.commentId,
          postData.employeeId
        )
    }
 

}
