import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Create } from './create';

@Injectable({
  providedIn: 'root'
})
export class CreateService {

  private url : string = 'http://localhost:8080/api/v1/application';
  constructor(private http : HttpClient) { }


  getCreateApplication(
    amountApplied: 0,
    applicationId: string,
    applicationState: string,
      comment: string,
    commentBy: string,
    commentId: string,
    documentId: string,
    link: string,
    submitted: true,
    title: string,
    employee: string,
    formNumber: string,
    location: string,
    los: string,
    priority: 0,
    receivedDate: string,
    team: string,
    tenure: 0 ,
  
    ){
    const postData : Create = {
     
    amountApplied: 0,
    applicationId: applicationId,
    applicationState: applicationState,
      comment: comment,
    commentBy: commentBy,
    commentId: commentId,
    documentId: documentId,
    link: link,
    submitted: true,
    title: title,
    employee: employee,
    formNumber: formNumber,
    location: location,
    los: los,
    priority: 0,
    receivedDate: receivedDate,
    team: team,
    tenure: 0,
    customerId:'',
    employeeId: ''
  
    }
    return this.http.post('http://localhost:8080/api/v1/application',postData).subscribe((responseData)=>
    {
      console.log(responseData);
    })
  }

  getSearchApplication(
    customerId: string,
  employeeId: string
  ){
    const postData : Create = {
      customerId: customerId,
      employeeId: employeeId,
      amountApplied: 0,
      applicationId: '',
      applicationState: '',
      comment: '',
      commentBy: '',
      commentId: '',
      documentId: '',
      link: '',
      submitted: true,
      title: '',
      employee: '',
      formNumber: '',
      location: '',
      los: '',
      priority: 0,
      receivedDate: '',
      team: '',
      tenure: 0
    } 
    return this.http.post('http://localhost:8080/api/v1/application/search',postData).subscribe((responseData)=>
    {
      console.log(responseData);
    })
  }

}
