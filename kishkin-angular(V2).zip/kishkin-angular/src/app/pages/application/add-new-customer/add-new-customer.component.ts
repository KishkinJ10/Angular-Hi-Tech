
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { App } from './app';

import { NewApplicationService } from './new-customer.service';



@Component({
  selector: 'app-add-new-customer',
  templateUrl: './add-new-customer.component.html',
  styleUrls: ['./add-new-customer.component.css']
})
export class AddNewCustomerComponent implements OnInit {

 
  constructor(private _newApplicationService : NewApplicationService){}

  ngOnInit(){
     
  }

  message : boolean = false;

  getCreateCustomerAPI(postData : App , postForm : NgForm){
    this._newApplicationService.getCreateCustomer(
      postData.aadharId,
      postData.address,
      postData.city,
      postData.country,
      postData.customerId,
      postData.dateOfBirth,
      postData.designation,
      postData.emails, 
      postData.firstName,
      postData.jobProfile,
      postData.lastName,
      postData.middleName,
      postData.monthlySalary,
      postData.pan,
      postData.passbooks,
      postData.phoneNumber,
      postData.pinCode,
      postData.state,
      postData.title
   )
   console.log("Create Customer API Called!!");
   postForm.reset();
   this.message = true;
   
    }
    
    closeAlert(){
      this.message=false;
    }

  

  
  
}
