import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { App } from './app';
@Injectable({
  providedIn: 'root'
})
export class NewApplicationService {

  private url : string = 'http://localhost:9900/api/v1/customer';
  constructor(private http : HttpClient) { }


  getCreateCustomer(   aadharId: string,
    address: string,
    city: string,
    country: string,
    customerId: string,
    dateOfBirth: string,
    designation: string,
    emails:  string ,
    firstName: string,
    jobProfile: string,
    lastName: string,
    middleName: string,
    monthlySalary: string,
    pan: string,
    passbooks: string,
    phoneNumber: string,
    pinCode: string,
    state: string,
    title: string
   ){
    const postData : App = {
      aadharId: aadharId,
      address: address,
      city: city,
      country: country,
      customerId: customerId,
      dateOfBirth: dateOfBirth,
      designation: designation,
      emails:  emails,
      firstName: firstName,
      jobProfile: jobProfile,
      lastName: lastName,
      middleName: middleName,
      monthlySalary: monthlySalary,
      pan: pan,
      passbooks: passbooks,
      phoneNumber: phoneNumber,
      pinCode: pinCode,
      state: state,
      title: title
    
  }
    return this.http.post('http://localhost:9900/api/v1/customer',postData).subscribe((responseData)=>
    {
      console.log(responseData);
    })
  }

  
}


