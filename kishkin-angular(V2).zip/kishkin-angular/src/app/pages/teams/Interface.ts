export interface Interface {
    
    employeeIds:string,
      teamId: string,
      teamName: string

}
