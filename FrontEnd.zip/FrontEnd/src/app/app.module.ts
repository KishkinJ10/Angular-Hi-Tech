import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule,routingComponent} from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './pages/base/header/header.component';
import { SidenavComponent } from './pages/base/sidenav/sidenav.component';
import { HomeComponent } from './pages/base/home/home.component';
import { CreateApplicationComponent } from './pages/application/create-application/create-application.component';
import { SearchApplicationComponent } from './pages/application/search-application/search-application.component';
import { MyApplicationComponent } from './pages/application/my-application/my-application.component';
import { UpdateBankComponent } from './pages/bank/update-bank/update-bank.component';
import { CreateEmployeeComponent } from './pages/employee/create-employee/create-employee.component';
import { SearchEmployeeComponent } from './pages/employee/search-employee/search-employee.component';
import { EditEmployeeComponent } from './pages/employee/edit-employee/edit-employee.component';
import { TeamsComponent } from './pages/teams/teams.component';

import { CalculatorComponent } from './pages/calculator/calculator.component';
import { AddNewCustomerComponent } from './pages/application/add-new-customer/add-new-customer.component';
import { AddExistingCustomerComponent } from './pages/application/add-existing-customer/add-existing-customer.component';

import { RegisterComponent } from './pages/register/register.component';
import { SecureComponent } from './pages/secure/secure.component';
import { NotFoundComponent } from './pages/not-found/not-found.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import {HTTP_INTERCEPTORS, HttpClientModule} from '@angular/common/http';
import {AuthInterceptor} from './auth.interceptor';

import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatInputModule} from '@angular/material/input';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatSortModule} from '@angular/material/sort';
import {MatButtonModule} from '@angular/material/button';
import {MatCardModule} from '@angular/material/card';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatTableModule} from '@angular/material/table';
import {MatIconModule} from '@angular/material/icon';



@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SidenavComponent,
    HomeComponent,
    CreateApplicationComponent,
    SearchApplicationComponent,
    MyApplicationComponent,
    
  
    UpdateBankComponent,
    CreateEmployeeComponent,
    SearchEmployeeComponent,
    EditEmployeeComponent,
    TeamsComponent,
    routingComponent,
        CalculatorComponent,
        AddNewCustomerComponent,
        AddExistingCustomerComponent,
        RegisterComponent,
        SecureComponent,
        NotFoundComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    
    FormsModule,
    ReactiveFormsModule,
    MatInputModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatSortModule,
    MatTableModule,
    MatIconModule,
    MatButtonModule,
    MatCardModule,
    MatFormFieldModule
  
  ],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: AuthInterceptor,
    multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
