import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-application',
  templateUrl: './search-application.component.html',
  styleUrls: ['./search-application.component.css']
})
export class SearchApplicationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
