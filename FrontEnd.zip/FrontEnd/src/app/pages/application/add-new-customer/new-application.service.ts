import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { App } from './app';
@Injectable({
  providedIn: 'root'
})
export class NewApplicationService {


  private url : string = 'http://localhost:8080/api/v1/application';
  constructor(private http : HttpClient) { }

  getCreateApplication(): Observable<App[]>{
  return this.http.get<App[]>(this.url);
  }

  
}


