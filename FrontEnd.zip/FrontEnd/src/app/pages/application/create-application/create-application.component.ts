import { Component, OnInit } from '@angular/core';



@Component({
  selector: 'app-create-application',
  templateUrl: './create-application.component.html',
  styleUrls: ['./create-application.component.css']
})
export class CreateApplicationComponent implements OnInit {



  constructor() { }


  ngOnInit(): void {
   
  }
 

}
