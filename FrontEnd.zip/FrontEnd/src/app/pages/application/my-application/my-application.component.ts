import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-application',
  templateUrl: './my-application.component.html',
  styleUrls: ['./my-application.component.css']
})
export class MyApplicationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
