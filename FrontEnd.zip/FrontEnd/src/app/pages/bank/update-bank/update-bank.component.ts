import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-bank',
  templateUrl: './update-bank.component.html',
  styleUrls: ['./update-bank.component.css']
})
export class UpdateBankComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
