import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-bank',
  templateUrl: './create-bank.component.html',
  styleUrls: ['./create-bank.component.css']
})
export class CreateBankComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
